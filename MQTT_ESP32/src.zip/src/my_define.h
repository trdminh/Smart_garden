#ifndef __MY_DIFINE_H__
#define __MY_DIFINE_H__

#define SSID1 "Chien"
#define PASSWORD "66666666"
#define MQTT_BROKER "broker.mqttdashboard.com"
#define MQTT_PORT 1883
#define TOPIC_PUB "Esp32/Mqtt"
#define TOPIC_SUB "Smart_Garden"
#define MQTT_USERNAME "Demo"
#define MQTT_PASSWORD "public"

#define SOIL_TEST       4
#define RELAY_LED      17
#define RELAY_PUMP     14
#define RELAY_FAN      27
#define DHT_SENSOR     23
#define BTN_SETUP      26
#define BTN_UP         25
#define BTN_DOWN       33
#define BTN_FAN        35
#define BTN_LED        32
#define BTN_PUMP       34


#endif
